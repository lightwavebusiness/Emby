﻿kango.ui.browserButton.setPopup({
    url: 'main.html',
    width: 710,
    height: 510
});

kango.ui.browserButton.addEventListener(kango.ui.browserButton.event.COMMAND, function() {
    kango.console.log('Button clicked!');
});
